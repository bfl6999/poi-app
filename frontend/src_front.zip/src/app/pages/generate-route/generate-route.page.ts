import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Auth, getIdToken, onAuthStateChanged, User } from '@angular/fire/auth';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-generate-route',
  templateUrl: './generate-route.page.html',
  styleUrls: ['./generate-route.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, ReactiveFormsModule]
})
export class GenerateRoutePage implements OnInit {
  form!: FormGroup;
  user: User | null = null;
  routeResult = '';
  loading = false;

  constructor(
    private fb: FormBuilder,
    private auth: Auth,
    private http: HttpClient
  ) {}

  ngOnInit() {
    this.form = this.fb.group({
      city: ['', Validators.required]
    });

    onAuthStateChanged(this.auth, user => {
      this.user = user;
    });
  }

  async generate() {
    if (!this.form.valid || !this.user) return;

    this.loading = true;
    this.routeResult = '';

    try {
      const token = await getIdToken(this.user);
      const headers = new HttpHeaders({
        Authorization: `Bearer ${token}`
      });

      const res: any = await this.http.post(
        'http://localhost:3000/api/pois/generate-route',
        { city: this.form.value.city },
        { headers }
      ).toPromise();

      this.routeResult = res.routePlan;
    } catch (err) {
      console.error('Error generando ruta', err);
      this.routeResult = 'Ocurrió un error generando la ruta.';
    } finally {
      this.loading = false;
    }
  }
}