export const environment = {
production: false,
firebaseConfig: {
  apiKey: "AIzaSyBGrXD6Tc3GYO66XEcEU7I09reXSgepOQQ",
  authDomain: "project-poi-a5f54.firebaseapp.com",
  projectId: "project-poi-a5f54",
  storageBucket: "project-poi-a5f54.firebasestorage.app",
  messagingSenderId: "94497583848",
  appId: "1:94497583848:web:fc3c34d19a9ab698158f5d"
  },
  apiUrl: 'http://localhost:3000/api',
  
};