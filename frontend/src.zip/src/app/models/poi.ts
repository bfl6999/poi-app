export interface Poi2 {
}
